function addList(letter) {
    // pass in the letter that was clicked

    // add the letter to the word that is displayed
    var word = document.getElementById('myword').value + letter; // ca
    document.getElementById('myword').value = word; // cag
    // Document Object Model (DOM)
}

function deleteLetter(event) {
    var word = document.getElementById('myword').value; // ca
    word = word.substring(0, word.length - 1);
    document.getElementById('myword').value = word; // cag

}

//function newGame(event) {



//}
/*
function enterWord() {
    words[];
    word = request.form.get("word") // get the submitted word from the form ...
    words.append(word)
}
*/
// submit button passes
// form submit the word then in python go through the logic and instead of printing out you re-render website through jinja
// mozilla good docs on javascript classes, stack overflow
// makes clickable buttons that display the word first
