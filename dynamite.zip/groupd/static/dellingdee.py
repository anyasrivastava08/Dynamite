import flask
import os
from flask import Flask, flash, redirect, render_template, request

# ...


words = []
@app.route("/dellingdee", methods=["GET", "POST"])
def delling():
    app = Flask(__name__)
    if request.method == "GET": # user submitted a word
        word = request.form.get("word")
        return render_template("dellingdee.html", words = words) # load page with.  ...., words=words

    if request.method == "POST": # if method is post
        word = request.form.get("word") # get the submitted word from the form ...
        words.append(word)


# delling dee game file starts
import random

dictionary = []
allUnique7 = []
letters = []
guessed = []
spangram = ""
midLetter = ""
points = 0
strikes = 0
playing = False
highScore = 0

#returns number of unique letters in a word
def num_unique(str):
    unique = 0
    with open('alphabet.txt', 'r') as f:
        alpha = f.readlines()
    for letter in alpha:
        if str.count(letter.strip()) > 0:
            unique += 1
    return unique

#picks random spangram out of array
def newSpangram():
    global spangram
    #adds eligible guessing words to new dictionary
    with open('dictionary.txt', 'r') as f:
        dict = f.readlines()
    for word in dict:
        word = word.strip()
        if len(word) > 3 and num_unique(word) < 8:
            dictionary.append(word)
    #adds eligible spangrams to new dictionary
    for word in dictionary:
        if num_unique(word) == 7:
            allUnique7.append(word)
    newSpangram = random.choice(allUnique7)
    spangram = newSpangram

#picks random letter out of spangram
def newMidLetter():
    global midLetter
    newMidLetter = random.choice(spangram)
    midLetter = newMidLetter

#returns letters of spangram in random order
def randomizeLetters():
    global letters
    noRepeats = []
    with open('alphabet.txt', 'r') as f:
        alpha = f.readlines()
    for letter in alpha:
        letter = letter.strip()
        if spangram.count(letter) > 0:
            noRepeats.append(letter)
    letters = noRepeats

#returns true if word only contains correct letters
def correctLetters(str):
    notIncluded = 0
    for letter in str:
        if letters.count(letter) == 0:
            notIncluded += 1
    if notIncluded > 0:
        return False
    else:
        return True

#returns true if the word is in the dictionary and is made up of only the right letters
def isValid(str):
    global dictionary
    if dictionary.count(str) > 0 and correctLetters(str):
        return True
    else:
        return False

def main():
    global playing
    global points
    global strikes
    global letters
    global guessed
    global highScore
    newSpangram()
    newMidLetter()
    randomizeLetters()
    points = 0
    strikes = 0
    play = input("would you like to play a new game? enter yes or no ")
    if play == "yes":
        playing = True
        print()
        print("here are your letters:", letters)
        print("all words must be 4+ letters and include:", midLetter)
        print("if you enter more than 3 incorrect words the game ends")
    if play == "no":
        playing = False
    while playing == True:
        print()
        s = input("enter your word: (to end the game at any point enter stp)")
        if guessed.count(s) > 0:
            print("already guessed")
        elif s == "stp":
            print()
            print("good game! you scored",points ,"points!")
            print("the spangram was", spangram)
            if points > highScore:
                print("new high score!")
                highScore = points
            else:
                print("keep trying to beat the current highscore of",highScore,"points!")
            print()
            playing == False
            main()
        elif s == spangram:
            print("you found the spangram! +10 points!")
            points += 10
        elif isValid(s) == True and s.find(midLetter) > -1:
            if len(s) < 5:
                print("correct! +1 point")
                points += 1
            elif len(s) < 6:
                print("correct! +2 points")
                points += 2
            elif len(s) < 7:
                print("correct! +3 points")
                points += 3
            elif len(s) < 8:
                print("correct! +4 points")
                points += 4
            else:
                print("correct! +5 points")
                points += 5
        else:
            print("incorrect")
            if s.find(midLetter) == -1:
                print("word must include", midLetter)
            if len(s) < 4:
                print("word is too short")
            strikes += 1
            print("strike", strikes, "/3")
        guessed.append(s)
        if strikes == 3:
            playing = False
            print()
            print("good game! you scored ",points ,"points!")
            print("the spangram was", spangram)
            print()
            if points > highScore:
                print("new high score!")
                highScore = points
            else:
                print("keep trying to beat the current highscore of",highScore,"points!")
            main()

main()
