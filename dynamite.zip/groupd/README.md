## THE DYNAMITE DEBUGGING DEMONS DYNAMITE GAMES

Over the course of the past week we recreated our favorite New York Times mini game: spelling bee
We built this game on its own website using javascript, css, html, and python
Like the actual game this will generate 7 random letters and one that you must include in all words
The goal is to make as many words as possible with the letters and find the spangram or original longest word containing all the letters

## How to Download:
    1. https://github.com/code50/175956558/blob/d671e4f653ebac6f94f9b45da71c7d6472441b41/groupd
    2.

## How to Play:
Click letter buttons to type out word that meets criteria of longer than 3 letters and containing the special letter
Click submit to earn points based on word length
Keep playing until you get three strikes (three incorrect words inputted)
See what the spangram was as the game resets itself!

## Authors!
Caroline Baker
Anya Srivastava
Tara MacNeil
Muirenn O'Hea
