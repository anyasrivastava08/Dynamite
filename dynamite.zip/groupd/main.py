# SQL part
import random

from cs50 import SQL
import os
from flask import Flask, flash, redirect, render_template, request

"""
CREATE TABLE players (id INTEGER, name TEXT, wordlewin3 INTEGER, PRIMARY KEY (id), UNIQUE (name) ON CONFLICT IGNORE);
INSERT INTO players (name, wordlewin3) VALUES ('DrB', 2);
SELECT name FROM players;
"""

dbfile = "data.db"


# # check if this file already exists
# if os.path.exists(dbfile):
#     # if it does, just load the file
#     db = SQL("sqlite:///" + dbfile)
# # if it does not yet exist, create the file first
# else:
#     open(dbfile, "w").close()
#     db = SQL("sqlite:///" + dbfile)


#     db.execute("CREATE TABLE players (id INTEGER, name TEXT, wordlewin3 INTEGER, PRIMARY KEY (id), UNIQUE (name) ON CONFLICT IGNORE);")
#     db.execute("CREATE TABLE strands (id INTEGER, player_id INTEGER, gamenum INTEGER, PRIMARY KEY (id), FOREIGN KEY(player_id) REFERENCES players(id));")

#     # insert data
#     players = ["Charlie", "Anya", "Muirenn", "DrB"]
#     for player in players:
#         db.execute("INSERT INTO players (name, wordlewin3) VALUES (?, 0);", player)

#     db.execute("INSERT INTO players (name, wordlewin3) VALUES (?, ?);", 3, 1)
#     db.execute("INSERT INTO players (name, wordlewin3) VALUES (?, ?);", 3, 5)
#     db.execute("INSERT INTO players (name, wordlewin3) VALUES (?, ?);", 2, 1)
#     db.execute("INSERT INTO players (name, wordlewin3) VALUES (?, ?);", 1, 5)

# # view data
# mydata = db.execute("SELECT * FROM players;")
# # access name, for example: mydata[0]['name]
# for player in mydata:
#     print(player['name'], player['wordlewin3'])

# player_strands = db.execute("SELECT * FROM strands WHERE player_id IN (SELECT id FROM players WHERE name = 'Muirenn');")
# print(player_strands)

# Flask stuff

# sets up my Flask application
app = Flask(__name__, static_url_path='/static')

"""
index.html
profile.html
games/wordle.html
games/connections.html
"""

@app.route("/", methods=["GET"]) # either have to leave out entirely or spell out GET
def index():
    # do stuff with my data
    # html4data = makethissomehow()
    return render_template("index.html", motto="Work hard, play hard!") # produces the file

# guesses = []
# # jinja - google jinja syntax
# # export FLASK_RUN="main.py"
# # flask run
# @app.route("/games/wordle", methods=["GET", "POST"]) # either have to leave out entirely or spell out GET - GET method means users can only GET data (POST would mean users can POST on the website)
# def wordle():
#     if request.method == "POST": # user submitted a guess
#         guess = request.form.get("guess")
#         guesses.append(guess)
#         # add guess to guesses
#         return render_template("wordle.html", guesses = guesses)
#     else: # assume "GET" - we need to display the state of the wordle

        #return render_template("wordle.html", guesses = guesses) # produces the file

def num_unique(str):
    unique = 0
    with open('alphabet.txt', 'r') as f:
        alpha = f.readlines()
    for letter in alpha:
        if str.count(letter.strip()) > 0:
            unique += 1
    return unique

def newSpangram():
    global spangram
    #adds eligible guessing words to new dictionary
    with open('dictionary.txt', 'r') as f:
        dict = f.readlines()
    for word in dict:
        word = word.strip()
        if len(word) > 3 and num_unique(word) < 8:
            dictionary.append(word)
    #adds eligible spangrams to new dictionary
    for word in dictionary:
        if num_unique(word) == 7:
            allUnique7.append(word)
    newSpangram = random.choice(allUnique7)
    spangram = newSpangram

def newMidLetter():
    global midLetter
    newMidLetter = random.choice(spangram)
    midLetter = newMidLetter

def randomizeLetters():
    global letters
    noRepeats = []
    with open('alphabet.txt', 'r') as f:
        alpha = f.readlines()
    for letter in alpha:
        letter = letter.strip()
        if spangram.count(letter) > 0:
            noRepeats.append(letter)
    letters = noRepeats

def correctLetters(str):
    notIncluded = 0
    for letter in str:
        if letters.count(letter) == 0:
            notIncluded += 1
    if notIncluded > 0:
        return False
    else:
        return True

def isValid(str):
    global dictionary
    if dictionary.count(str) > 0 and correctLetters(str):
        return True
    else:
        return False

dictionary = []
allUnique7 = []
highScore = 0
letters = []
spangram = ""
midLetter = ""
words = []
iguesses = []
guesses = []
span = ""


newSpangram()
newMidLetter()
randomizeLetters()
points = 0
strikes = 0
@app.route("/games/dellingdee", methods=["GET", "POST"])
def delling():
    global span
    global letters
    global spangram
    global words
    global guesses
    global iguesses
    global strikes
    global points
    if request.method == "POST": # if method is post
        word = request.form.get("word") # get the submitted word from the form ...
        #words.append(word)
        if words.count(word) > 0:
            print("already guessed")
        elif isValid(word) == True and word.find(midLetter) > -1:
            guesses.append(word)
            if word == spangram:
                points += 10
            elif len(word) < 5:
                points += 1
            elif len(word) < 6:
                points += 2
            elif len(word) < 7:
                points += 3
            elif len(word) < 8:
                points += 4
            else:
                points += 5
        elif (isValid(word) == False or word.find(midLetter) == -1) and word != "":
            iguesses.append(word)
            strikes += 1
        if strikes >= 3:
            span = spangram
            newSpangram()
            newMidLetter()
            randomizeLetters()
            points = 0
            strikes = 0
            iguesses = []
            guesses = []


    return render_template("dellingdee.html", span=span, letters=letters, words=words, midLetter=midLetter, iguesses=iguesses, guesses=guesses, points=points, strikes=strikes)

